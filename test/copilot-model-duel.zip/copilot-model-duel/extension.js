const vscode = require('vscode');

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand('modelDuel.start', () => startDuel())
  );
}

/** Copilot のモデル一覧から1つ選ばせる */
async function pickModel(models, placeHolder) {
  const items = models.map((m) => ({
    label: m.name,
    description: `${m.vendor}/${m.family}`,
    detail: `id: ${m.id} · max input tokens: ${m.maxInputTokens}`,
    model: m,
  }));
  const pick = await vscode.window.showQuickPick(items, {
    placeHolder,
    ignoreFocusOut: true,
  });
  return pick && pick.model;
}

function persona(selfName, otherName) {
  return (
    `あなたは「${selfName}」です。別のAIモデル「${otherName}」とベンチマーク対話をしています。` +
    `共通のお題に対し、まず自分の考えを述べ、相手の発言が出たらその内容と自分の考えを具体的に比較し、` +
    `相違点・優劣・見落としを根拠を示して指摘してください。相手に安易に同調せず、議論を深めること。` +
    `日本語で、簡潔かつ濃密に答えてください。`
  );
}

async function startDuel() {
  const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
  if (!models || models.length === 0) {
    vscode.window.showErrorMessage(
      'Copilot のモデルが取得できませんでした。GitHub Copilot にサインインしているか確認してください。'
    );
    return;
  }

  const modelA = await pickModel(models, 'モデルA を選択（例: Claude Opus）');
  if (!modelA) return;
  const modelB = await pickModel(models, 'モデルB を選択（例: GPT）');
  if (!modelB) return;

  const topic = await vscode.window.showInputBox({
    prompt: '2モデルに投げる共通の問い／お題',
    ignoreFocusOut: true,
  });
  if (!topic) return;

  const roundsStr = await vscode.window.showInputBox({
    prompt: 'ラウンド数（各モデルが発言する回数。1ラウンド = A→B）',
    value: '3',
    ignoreFocusOut: true,
  });
  const rounds = Math.max(1, parseInt(roundsStr || '3', 10) || 3);

  const nameA = modelA.name;
  const nameB = modelB.name;
  const tokenSource = new vscode.CancellationTokenSource();

  // ライブ表示用の Output チャネル
  const channel = vscode.window.createOutputChannel('Model Duel');
  channel.show(true);

  // 最終的に Markdown 文書として残すためのバッファ
  let md = `# モデル対話: ${nameA} vs ${nameB}\n\n**お題:** ${topic}\n\n---\n\n`;
  const emit = (text) => {
    md += text;
    channel.append(text);
  };

  // 会話履歴: { speaker: 'A' | 'B', text }
  const transcript = [];

  /**
   * 1モデルの発言を生成してストリーミング表示する。
   * blind=true のときは相手の発言（transcript）を渡さず、お題のみで回答させる。
   */
  async function turn(model, self, selfName, otherName, blind) {
    const messages = [
      vscode.LanguageModelChatMessage.User(
        `${persona(selfName, otherName)}\n\n# お題\n${topic}`
      ),
    ];

    if (blind) {
      messages.push(
        vscode.LanguageModelChatMessage.User(
          'まだ相手の発言はありません。お題に対するあなたの回答を述べてください。'
        )
      );
    } else {
      for (const entry of transcript) {
        if (entry.speaker === self) {
          messages.push(vscode.LanguageModelChatMessage.Assistant(entry.text));
        } else {
          messages.push(
            vscode.LanguageModelChatMessage.User(
              `【${otherName} の発言】\n${entry.text}`
            )
          );
        }
      }
    }

    emit(`## ${selfName}\n\n`);
    const resp = await model.sendRequest(messages, {}, tokenSource.token);
    let full = '';
    for await (const chunk of resp.text) {
      full += chunk;
      emit(chunk);
    }
    emit('\n\n---\n\n');
    transcript.push({ speaker: self, text: full });
  }

  try {
    for (let r = 0; r < rounds; r++) {
      const blind = r === 0; // 初回ラウンドはブラインド（公平な比較の起点）
      emit(`### Round ${r + 1}${blind ? '（ブラインド回答）' : ''}\n\n`);
      await turn(modelA, 'A', nameA, nameB, blind);
      await turn(modelB, 'B', nameB, nameA, blind);
    }
    emit('\n_対話終了_\n');

    const doc = await vscode.workspace.openTextDocument({
      language: 'markdown',
      content: md,
    });
    await vscode.window.showTextDocument(doc, { preview: false });
  } catch (err) {
    const message = err && err.message ? err.message : String(err);
    emit(`\n\n> エラー: ${message}\n`);
    vscode.window.showErrorMessage('対話中にエラー: ' + message);
  } finally {
    tokenSource.dispose();
  }
}

function deactivate() {}

module.exports = { activate, deactivate };
