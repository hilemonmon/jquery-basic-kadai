# Copilot Model Duel

GitHub Copilot（Enterprise 含む）の2モデル — 例: **Claude Opus** と **GPT** — を
自動リレーで会話・相互比較させる最小 VS Code 拡張。

Copilot の `vscode.lm` API を使うため **別途 API キーは不要**。利用は Copilot の課金内。

## 使い方

1. このフォルダ `copilot-model-duel/` を VS Code で開く。
2. `F5` を押す（`.vscode/launch.json` の "Run Extension" が起動）。
   - 新しい VS Code ウィンドウ（Extension Development Host）が開く。
   - そのウィンドウは **GitHub Copilot にサインイン済み**である必要がある。
3. コマンドパレット（`Ctrl+Shift+P`）→ **「Model Duel: 2モデルを対話させる」**。
4. プロンプトに従って入力:
   - モデルA を選択（例: Claude Opus）
   - モデルB を選択（例: GPT-4o / GPT-5 など）
   - 共通のお題（2モデルに投げる問い）
   - ラウンド数（既定 3）
5. **Output パネルの "Model Duel"** に会話がストリーミング表示され、
   終了時に全文が **Markdown 文書**として開く。
6. 初回の `sendRequest` で Copilot の言語モデル利用の**同意ダイアログ**が出るので許可する。

## 対話の流れ（ベンチ用途）

- **Round 1 はブラインド**: 両モデルが互いの回答を見ずに同じお題へ独立回答（公平な比較の起点）。
- **Round 2 以降は相互批評**: 相手の発言を読ませ、相違点・優劣・見落としを根拠付きで指摘させ議論を深める。

## カスタマイズ

- 役割づけ（プロンプト）は `extension.js` の `persona()` を編集。
  - 例: 「片方が提案・片方が批判」「採点者として相手を10点満点で評価」など。
- 同じお題で複数回流して回答の安定性を見るなど、ベンチ観点で `turn()` を拡張可能。

## 注意

- 選べるモデルの family 名は Copilot の契約・提供状況に依存する（QuickPick に出るものから選ぶ）。
- これは未公開（ローカル開発）拡張。常用したい場合は `vsce package` で `.vsix` 化してインストールできる。
